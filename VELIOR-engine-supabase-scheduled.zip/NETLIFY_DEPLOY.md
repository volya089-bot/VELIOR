# Deploy to Netlify (GitHub route)

## Why GitHub
You want:
- Stripe webhook
- Scheduled checks (cron)
These require Netlify Functions, which need a build/deploy pipeline (Git).

## Steps
1) Create GitHub repo and upload this folder
2) Netlify → Add new site → Import from Git → select repo
3) Netlify will read `netlify.toml`:
   - build: `npm run build`
   - publish: `dist`
   - functions: `netlify/functions`

## Set environment variables (Site settings → Environment variables)
- SUPABASE_URL
- SUPABASE_ANON_KEY
- SUPABASE_SERVICE_ROLE_KEY
- STRIPE_SECRET_KEY
- STRIPE_WEBHOOK_SECRET
- NEXT_PUBLIC_APP_URL (your deployed url)

## Stripe webhook URL
`https://YOUR_DOMAIN/.netlify/functions/stripe-webhook`

## First test
- Visit `/pricing` → click plan → complete test purchase
- Visit `/app` → create account with same email
- Refresh `/app` → access should become active (webhook inserts entitlement)
- Create monitor + rule → wait up to 10 min → refresh events
