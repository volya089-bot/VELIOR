const { runAllChecks } = require("./_runner");

/**
 * Netlify Scheduled Function
 * Runs every 10 minutes. Change schedule below if needed.
 */
exports.config = { schedule: "*/10 * * * *" };

exports.handler = async () => {
  try{
    const res = await runAllChecks();
    return { statusCode: 200, body: JSON.stringify(res) };
  }catch(err){
    return { statusCode: 500, body: JSON.stringify({ ok:false, error: err.message }) };
  }
};
