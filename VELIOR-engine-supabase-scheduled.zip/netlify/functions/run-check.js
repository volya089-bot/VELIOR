const { runAllChecks } = require("./_runner");

exports.handler = async () => {
  try{
    const res = await runAllChecks();
    return { statusCode: 200, body: JSON.stringify(res) };
  }catch(err){
    return { statusCode: 500, body: JSON.stringify({ ok:false, error: err.message }) };
  }
};
