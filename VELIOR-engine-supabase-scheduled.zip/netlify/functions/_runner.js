const { getAdminSupabase } = require("./_supabase");

// CoinGecko simple endpoints
async function fetchSimplePrice(assetIds, vs){
  const ids = assetIds.join(",");
  const url = `https://api.coingecko.com/api/v3/simple/price?ids=${encodeURIComponent(ids)}&vs_currencies=${encodeURIComponent(vs)}&include_24hr_change=true`;
  const res = await fetch(url, { headers: { "accept":"application/json" }});
  if(!res.ok) throw new Error(`CoinGecko error ${res.status}`);
  return await res.json();
}

function nowIso(){ return new Date().toISOString(); }

async function runAllChecks(){
  const supabase = getAdminSupabase();

  // Load enabled monitors
  const { data: monitors, error: mErr } = await supabase
    .from("monitors")
    .select("*")
    .eq("is_enabled", true);

  if(mErr) throw mErr;
  if(!monitors || monitors.length === 0){
    return { ok:true, ran:0, triggered:0 };
  }

  // Group by vs_currency to minimize calls
  const byVs = new Map();
  for(const m of monitors){
    const key = m.vs_currency || "eur";
    if(!byVs.has(key)) byVs.set(key, []);
    byVs.get(key).push(m);
  }

  let triggered = 0;

  for(const [vs, list] of byVs.entries()){
    const assetIds = [...new Set(list.map(x=>x.asset_id))];
    const priceMap = await fetchSimplePrice(assetIds, vs);

    // Load alert rules for these monitors
    const monitorIds = list.map(x=>x.id);
    const { data: rules, error: rErr } = await supabase
      .from("alert_rules")
      .select("*")
      .in("monitor_id", monitorIds)
      .eq("is_enabled", true);

    if(rErr) throw rErr;

    // index rules per monitor
    const rulesByMonitor = new Map();
    for(const r of (rules||[])){
      if(!rulesByMonitor.has(r.monitor_id)) rulesByMonitor.set(r.monitor_id, []);
      rulesByMonitor.get(r.monitor_id).push(r);
    }

    for(const m of list){
      const p = priceMap[m.asset_id];
      if(!p){
        // log info event for missing data
        await supabase.from("events").insert({
          user_id: m.user_id,
          monitor_id: m.id,
          severity: "warning",
          title: `Data unavailable: ${m.asset_id}`,
          body: "CoinGecko returned no data for this asset id.",
          data: { asset_id: m.asset_id, vs }
        });
        continue;
      }

      const price = p[vs];
      const change24 = p[`${vs}_24h_change`];

      // log run event (light)
      await supabase.from("events").insert({
        user_id: m.user_id,
        monitor_id: m.id,
        severity: "info",
        title: `Run: ${m.name}`,
        body: `price=${price} ${vs}, 24h_change=${(change24 ?? 0).toFixed?.(2) ?? change24}%`,
        data: { asset_id:m.asset_id, vs, price, pct_change_24h: change24, at: nowIso() }
      });

      const rulesForMonitor = rulesByMonitor.get(m.id) || [];
      for(const r of rulesForMonitor){
        // cooldown
        if(r.last_triggered_at){
          const last = new Date(r.last_triggered_at).getTime();
          const cd = (r.cooldown_minutes || 60) * 60 * 1000;
          if(Date.now() - last < cd) continue;
        }

        let hit = false;
        if(r.metric === "pct_change_24h"){
          hit = (change24 ?? 0) >= Number(r.threshold);
        }else if(r.metric === "price_above"){
          hit = Number(price) >= Number(r.threshold);
        }else if(r.metric === "price_below"){
          hit = Number(price) <= Number(r.threshold);
        }

        if(hit){
          triggered++;
          await supabase.from("events").insert({
            user_id: m.user_id,
            monitor_id: m.id,
            severity: r.metric === "pct_change_24h" ? "warning" : "critical",
            title: `ALERT: ${m.asset_id} ${r.metric} hit`,
            body: `threshold=${r.threshold}, price=${price} ${vs}, 24h_change=${change24}%`,
            data: { rule_id: r.id, metric:r.metric, threshold:r.threshold, price, pct_change_24h: change24, vs }
          });

          await supabase.from("alert_rules")
            .update({ last_triggered_at: nowIso() })
            .eq("id", r.id);
        }
      }
    }
  }

  return { ok:true, ran: monitors.length, triggered };
}

module.exports = { runAllChecks };
