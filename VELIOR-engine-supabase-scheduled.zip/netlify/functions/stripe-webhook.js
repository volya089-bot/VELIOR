const Stripe = require("stripe");
const { getAdminSupabase } = require("./_supabase");

exports.handler = async (event) => {
  try{
    const stripeSecret = process.env.STRIPE_SECRET_KEY;
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
    if(!stripeSecret || !webhookSecret){
      return { statusCode: 500, body: "Missing Stripe env vars" };
    }

    const stripe = new Stripe(stripeSecret, { apiVersion: "2023-10-16" });
    const sig = event.headers["stripe-signature"];
    const body = event.isBase64Encoded ? Buffer.from(event.body, "base64").toString("utf8") : event.body;

    let evt;
    try{
      evt = stripe.webhooks.constructEvent(body, sig, webhookSecret);
    }catch(err){
      return { statusCode: 400, body: `Webhook signature verification failed: ${err.message}` };
    }

    const supabase = getAdminSupabase();

    // Helper: upsert entitlement by email
    async function upsertEnt({ email, plan, status, customerId, subscriptionId, currentPeriodEnd }){
      if(!email) return;
      await supabase.from("entitlements").upsert({
        email,
        plan,
        status,
        stripe_customer_id: customerId || null,
        stripe_subscription_id: subscriptionId || null,
        current_period_end: currentPeriodEnd ? new Date(currentPeriodEnd * 1000).toISOString() : null
      }, { onConflict: "email" });
    }

    // Payment Links: checkout.session.completed is the key event
    if(evt.type === "checkout.session.completed"){
      const s = evt.data.object;

      // session has customer_details.email typically
      const email = (s.customer_details && s.customer_details.email) || s.customer_email || null;

      // Try get subscription to map plan
      let plan = "PRO";
      let status = "active";
      let subscriptionId = s.subscription || null;

      if(subscriptionId){
        const sub = await stripe.subscriptions.retrieve(subscriptionId);
        status = (sub.status === "active" || sub.status === "trialing") ? "active" : (sub.status || "inactive");
        const priceId = sub.items.data?.[0]?.price?.id;
        // Map known price IDs via env or fallback to PRO.
        // You can set STRIPE_PRO_PRICE_ID / STRIPE_BUSINESS_PRICE_ID for accuracy.
        const proPrice = process.env.STRIPE_PRO_PRICE_ID;
        const bizPrice = process.env.STRIPE_BUSINESS_PRICE_ID;
        if(bizPrice && priceId === bizPrice) plan = "BUSINESS";
        if(proPrice && priceId === proPrice) plan = "PRO";
      }

      await upsertEnt({
        email,
        plan,
        status,
        customerId: s.customer || null,
        subscriptionId,
        currentPeriodEnd: null
      });

      return { statusCode: 200, body: "ok" };
    }

    // invoice.paid keeps it active
    if(evt.type === "invoice.paid"){
      const inv = evt.data.object;
      const customerId = inv.customer;
      const subscriptionId = inv.subscription || null;

      // Find email: use Stripe customer
      let email = null;
      if(customerId){
        const c = await stripe.customers.retrieve(customerId);
        email = c.email || null;
      }

      // Determine plan by price id if provided
      let plan = "PRO";
      if(inv.lines?.data?.length){
        const priceId = inv.lines.data[0].price?.id;
        const proPrice = process.env.STRIPE_PRO_PRICE_ID;
        const bizPrice = process.env.STRIPE_BUSINESS_PRICE_ID;
        if(bizPrice && priceId === bizPrice) plan = "BUSINESS";
        if(proPrice && priceId === proPrice) plan = "PRO";
      }

      await upsertEnt({
        email,
        plan,
        status: "active",
        customerId,
        subscriptionId,
        currentPeriodEnd: inv.lines?.data?.[0]?.period?.end || null
      });

      return { statusCode: 200, body: "ok" };
    }

    if(evt.type === "customer.subscription.updated" || evt.type === "customer.subscription.deleted"){
      const sub = evt.data.object;
      const customerId = sub.customer;
      let email = null;
      if(customerId){
        const c = await stripe.customers.retrieve(customerId);
        email = c.email || null;
      }
      const st = sub.status;
      const status = (st === "active" || st === "trialing") ? "active" : (st === "past_due" ? "past_due" : "inactive");

      // Plan mapping by price id env
      let plan = "PRO";
      const priceId = sub.items.data?.[0]?.price?.id;
      const proPrice = process.env.STRIPE_PRO_PRICE_ID;
      const bizPrice = process.env.STRIPE_BUSINESS_PRICE_ID;
      if(bizPrice && priceId === bizPrice) plan = "BUSINESS";
      if(proPrice && priceId === proPrice) plan = "PRO";

      await upsertEnt({
        email,
        plan,
        status,
        customerId,
        subscriptionId: sub.id,
        currentPeriodEnd: sub.current_period_end || null
      });

      return { statusCode: 200, body: "ok" };
    }

    return { statusCode: 200, body: "ignored" };
  }catch(err){
    return { statusCode: 500, body: `error: ${err.message}` };
  }
};
