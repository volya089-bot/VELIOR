const fs = require("fs");
const path = require("path");

const src = path.join(__dirname, "site");
const out = path.join(__dirname, "dist");

function rm(dir){ if(fs.existsSync(dir)) fs.rmSync(dir, {recursive:true, force:true}); }
function cp(srcPath, outPath){
  const st = fs.statSync(srcPath);
  if(st.isDirectory()){
    fs.mkdirSync(outPath, {recursive:true});
    for(const name of fs.readdirSync(srcPath)){
      cp(path.join(srcPath,name), path.join(outPath,name));
    }
  } else {
    fs.mkdirSync(path.dirname(outPath), {recursive:true});
    fs.copyFileSync(srcPath, outPath);
  }
}

rm(out);
cp(src, out);

// Copy redirects if present
console.log("Built to dist/");
