/**
 * VELIOR public config (SAFE to expose).
 * Fill these in after creating Supabase project.
 */
window.VELIOR_CONFIG = {
  supabaseUrl: "https://YOUR_PROJECT.supabase.co",
  supabaseAnonKey: "YOUR_SUPABASE_ANON_KEY",
  appUrl: "http://localhost:8888", // set to your Netlify domain later (or leave)
  stripe: {
    proLink: "https://buy.stripe.com/5kQdR9gnHelNffBb7O0Ny00",
    businessLink: "https://buy.stripe.com/4gMaEX3AVgtV8RddfW0Ny01",
    promoCodes: [
      { code: "ЛАСКАВО ПРОСИМО5", label: "Welcome €5" },
      { code: "ЛАСКАВО ПРОСИМО10", label: "Referral reward €10" }
    ]
  }
};
