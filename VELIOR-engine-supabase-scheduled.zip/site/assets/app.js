function $(sel, root=document){ return root.querySelector(sel); }
function $all(sel, root=document){ return Array.from(root.querySelectorAll(sel)); }

function toast(msg){
  const el = document.createElement("div");
  el.className="alert";
  el.style.position="fixed";
  el.style.right="16px";
  el.style.bottom="16px";
  el.style.maxWidth="420px";
  el.style.zIndex="9999";
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(()=>{ el.style.opacity="0"; el.style.transition="opacity .25s"; }, 2200);
  setTimeout(()=>{ el.remove(); }, 2600);
}

async function copyText(text){
  try{
    await navigator.clipboard.writeText(text);
    toast("Copied");
  }catch(e){
    prompt("Copy:", text);
  }
}
