# VELIOR Engine (Supabase + Stripe + Netlify Scheduled Checks)

This repo deploys a **real product**:
- Landing: `/`
- Pricing: `/pricing`
- App (engine): `/app` (login + monitors + alerts + events)
- Stripe webhook endpoint: `/.netlify/functions/stripe-webhook`
- Scheduled checks (cron): `/.netlify/functions/scheduled-check`

## 1) Create Supabase project
Go to Supabase Dashboard → New project → pick org → set name + password.

### Run DB schema
Supabase → **SQL Editor** → **New query** → paste content of `supabase/schema.sql` → Run.

### Enable Auth
Supabase → **Authentication → Providers** → enable **Email**.

## 2) Stripe setup
You already have Payment Links.
Set **Success URL** of each Payment Link to:
`https://YOUR_DOMAIN/app`

### Webhook
Stripe Dashboard → Developers → Webhooks → Add endpoint:
`https://YOUR_DOMAIN/.netlify/functions/stripe-webhook`

Select events:
- `checkout.session.completed`
- `invoice.paid`
- `customer.subscription.updated`
- `customer.subscription.deleted`

Copy the webhook signing secret.

## 3) Netlify environment variables
Netlify → Site settings → Environment variables:

### Supabase
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`

### Stripe
- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`

### App
- `NEXT_PUBLIC_APP_URL` (example: `https://your-site.netlify.app` or custom domain)

### Optional notifications
- `RESEND_API_KEY` (optional)
- `ALERT_FROM_EMAIL` (optional, e.g. `alerts@yourdomain.com`)

## 4) Deploy (GitHub recommended)
1. Create a new GitHub repo
2. Upload this folder
3. Netlify → Add new site → Import from Git
4. Build command / publish are auto via `netlify.toml`

## Notes
- App access is gated by Stripe entitlement saved in Supabase.
- Scheduled checks run every 10 minutes by default (change in `netlify/functions/scheduled-check.js`).
