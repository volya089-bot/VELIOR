-- VELIOR Engine schema (minimal, production-friendly)

-- Users are managed by Supabase Auth.
-- We map entitlements by email for Stripe Payment Links simplicity.

create table if not exists public.entitlements (
  email text primary key,
  plan text not null check (plan in ('PRO','BUSINESS')),
  status text not null check (status in ('active','inactive','past_due','canceled')) default 'inactive',
  stripe_customer_id text,
  stripe_subscription_id text,
  current_period_end timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.monitors (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  name text not null,
  asset_type text not null default 'crypto' check (asset_type in ('crypto')),
  asset_id text not null, -- CoinGecko id (e.g. bitcoin, ethereum, solana)
  vs_currency text not null default 'eur',
  is_enabled boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.alert_rules (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  monitor_id uuid not null references public.monitors(id) on delete cascade,
  metric text not null check (metric in ('pct_change_24h','price_above','price_below')),
  threshold numeric not null,
  cooldown_minutes int not null default 60,
  last_triggered_at timestamptz,
  is_enabled boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  monitor_id uuid references public.monitors(id) on delete set null,
  severity text not null default 'info' check (severity in ('info','warning','critical')),
  title text not null,
  body text,
  data jsonb,
  created_at timestamptz not null default now()
);

-- RLS
alter table public.entitlements enable row level security;
alter table public.monitors enable row level security;
alter table public.alert_rules enable row level security;
alter table public.events enable row level security;

-- Entitlements: users can read ONLY their own row by email
create policy "entitlements_read_own"
on public.entitlements for select
using (auth.email() = email);

-- Monitors: user owns by auth.uid()
create policy "monitors_crud_own"
on public.monitors for all
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

create policy "alert_rules_crud_own"
on public.alert_rules for all
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

create policy "events_read_own"
on public.events for select
using (auth.uid() = user_id);

create policy "events_insert_own"
on public.events for insert
with check (auth.uid() = user_id);

-- Helpful indexes
create index if not exists monitors_user_id_idx on public.monitors(user_id);
create index if not exists alert_rules_user_id_idx on public.alert_rules(user_id);
create index if not exists events_user_id_idx on public.events(user_id);

-- Updated_at trigger for entitlements
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

drop trigger if exists entitlements_set_updated_at on public.entitlements;
create trigger entitlements_set_updated_at
before update on public.entitlements
for each row execute function public.set_updated_at();
